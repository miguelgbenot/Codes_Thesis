#!/bin/bash
taskset -c 0,1,2,3,4,5 ./SFcollapse1D 320 8 5.3162 0.08  3.36410350 # 0.3884
mv out_central_values.dat eta_f.dat
taskset -c 0,1,2,3,4,5 ./SFcollapse1D 320 8 5.3162 0.08  336.410351 
mv out_central_values.dat out_strong.dat
#python generate_plot.py
